do_eval <-
function(dataA,classlabels)
{
	
	
	
	
}
